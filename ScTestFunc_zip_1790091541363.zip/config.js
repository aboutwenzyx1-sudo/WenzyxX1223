module.exports = {
  // ─── BOT TELEGRAM ─────────────────────────────────────
  tokenBot: "8875131835:AAEurqwPhRajZjRWnr1vrQBgQBevmA987FE",
  ownerID: "8956641631",

  // ─── WEB PANEL ADMIN ──────────────────────────────────
  webAdmin: {
    username: "WHENZX",
    password: "WHENZXpzy",
    port: 3703,
    host: "0.0.0.0"
  },

  // ─── PM2 PROCESS NAME ─────────────────────────────────
  pm2BotName: "bot",

  // ─── SFTP (PTERODACTYL) ───────────────────────────────
  sftp: {
    enabled: false,
    host: "http://server1.shapetganteng.my.id",
    port: 3703,
    username: "WHENZX",
    password: "WHENZXpzy",
    remotePath: "/home/container/index.js"
  },

  // ─── GITHUB (BUILD APK) ───────────────────────────────
  github: {
    token: "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",
    owner: "aboutwenzyx1-sudo",
    repo: "WenzyxX1223",
    branch: "main"
  }
};